const express = require('express');
const http = require('http');
const WebSocket = require('ws');  // 'ws' 모듈 추가
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

mongoose.connect('mongodb://localhost:27017/Gonggan', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// 몽고디비 연결 확인
const db = mongoose.connection;
db.on('error', console.error.bind(console, '몽고디비 연결 오류:'));
db.once('open', () => {
    console.log('몽고디비에 연결되었습니다.');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/styles.css', (req, res) => {
    res.sendFile(__dirname + '/styles.css', { headers: { 'Content-Type': 'text/css' } });
});

app.post('/signup', (req, res) => {
    const { username, email, password } = req.body;

    // 여기에서 몽고디비에 데이터 저장하는 로직을 구현합니다.
    // mongoose 모델을 정의하고, 해당 모델을 사용하여 데이터를 저장합니다.
    const userSchema = new mongoose.Schema({
        username: String,
        email: String,
        password: String,
    });
    
    const User = mongoose.model('User', userSchema);
    res.send('회원가입이 완료되었습니다.');
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/styles.css', (req, res) => {
    res.sendFile(__dirname + '/styles.css', { headers: { 'Content-Type': 'text/css' } });
});

app.post('/signup', (req, res) => {
    const { username, email, password } = req.body;
    // 여기에서 회원가입 로직을 구현합니다.
    // 데이터베이스에 사용자 정보를 저장하거나 다른 작업을 수행합니다.
    // 성공 또는 실패에 따라 클라이언트에 응답을 보냅니다.
    res.send('회원가입이 완료되었습니다.');
});

wss.on('connection', (ws) => {
    // WebSocket 연결이 활성화되면 이 부분에서 처리를 수행할 수 있습니다.
    console.log('WebSocket 연결이 활성화되었습니다.');
});

server.listen(3000, () => {
    console.log('서버가 http://localhost:3000 에서 실행 중입니다.');
});
